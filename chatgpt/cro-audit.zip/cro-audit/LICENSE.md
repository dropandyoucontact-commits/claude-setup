# Licence

**Skill:** CRO Audit
**By:** CreativeDeals — https://creativedeals.nl
**Contact:** info@creativedeals.nl

This skill is shared for free.

## You may

- Use it for your own work and for your clients, commercially or otherwise.
- Modify and adapt it to your needs.
- Share it, provided this LICENSE and the CreativeDeals credit stay intact.

## Please

- Keep the attribution to CreativeDeals when you redistribute the files.
- Do not resell the skill itself as a paid product.

## No warranty

Provided "as is", without warranty of any kind. This skill produces evidence-based hypotheses to inform your testing, not guaranteed results; you are responsible for testing and validating any change before relying on it.

© 2026 CreativeDeals. Shared freely.
