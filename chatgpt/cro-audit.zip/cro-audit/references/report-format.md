# Report format

One report per page. Order fixes by expected impact, not by how easy they are to ship. Frame every recommendation as a hypothesis, because that is what it is until a test proves it.

## Structure

```markdown
# CRO audit — <url>

**Page type:** <homepage/landing/pricing/feature/blog/form>   **Goal:** <the one action>   **Traffic:** <cold ad / search / existing user>   **Date:** <date>

## Verdict
One paragraph: the biggest reason this page likely underconverts, and the single change most worth testing first.

## Quick wins (ship now)
Low-effort, low-risk fixes with a clear rationale. These do not need a test to justify shipping (a missing CTA above the fold, a vague button label, no proof near the price).

| Fix | Dimension | Why it should help |
|-----|-----------|--------------------|
| Add a primary CTA above the fold | CTA | Skimmers never see the action today |

## High-impact changes (test these)
Bigger bets that could move conversion meaningfully but carry more uncertainty, so they earn an A/B test.

For each: the change, the dimension, the assumed reason it will help, and **how to test it** (the variant, the metric, and roughly the traffic/time needed to read a result).

## Copy alternatives
For the headline and the primary CTA, 2-3 options each, with the reasoning (which angle, which objection or outcome it leans on). These are test variants, not a final answer.

## Objections not answered
The top objections for this offer and audience that the page currently ignores, and where to address each.

## Verified vs judged
- **From the scan:** headline presence, CTA detection and position, trust-signal and social-proof presence, form-field count, link count.
- **Judged this audit:** value-proposition clarity, copy quality, objection coverage, visual hierarchy.
- **Only a test can settle:** which variant actually converts better. Nothing here is a guaranteed lift.

## Appendix — scan output
The raw cro-scan.mjs output.
```

## Rules

- **Diagnose top-down.** Value proposition and headline before button colour. Do not lead with a friction tweak on a page whose offer is unclear.
- **Impact order, not effort order.** A hard, high-impact change outranks an easy, trivial one. Note effort, but rank by expected lift.
- **Every recommendation is a hypothesis.** State the assumed reason it helps. Never claim a change "will increase conversion X%"; you cannot know without a test.
- **Respect page type and traffic.** Do not apply landing-page rules to a homepage, or hard-conversion rules to a blog post.
- **Copy alternatives come with reasoning**, so the reader can pick and test, not just paste.
