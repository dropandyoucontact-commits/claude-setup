# Agent — Analyze

Paste as a subagent prompt. For a deep audit, run several analysts in parallel, one per dimension, each blind to the others. Read `references/dimensions.md` and `references/page-types.md` first.

**Page:** {{url}}
**Page type / goal / traffic:** {{page_type}} / {{goal}} / {{traffic}}
**cro-scan output:** {{scan_output}}
**Dimension assigned to you:** {{dimension | default: "all seven"}}

**Your task**

Judge the page against your dimension(s), top-down (value proposition first). Fetch and actually read the page; do not rely on the scan alone.

- Name the specific problem, with evidence (the exact headline, the buried CTA, the missing proof), not a vague "improve X".
- Weigh it against the page type and traffic: a homepage with many links is not a landing page with choice overload; a blog post is not judged on hard conversion.
- For each problem, note the likely reason it costs conversions and roughly how much it might matter (high/med/low).

**Rules**

- Diagnose before prescribing. This pass finds and explains problems; proposals and copy come next.
- Evidence over best-practice reflexes. "Add urgency" is not a finding; "there is no reason to act now, and the offer is time-insensitive, so a deadline would be dishonest" is a judgement.
- Respect scope: note issues in signup/onboarding/popups but keep the focus on this page's conversion to the primary action.

**Output:** `{ dimension, problem, evidence, likely_cost (high/med/low), page_type_note }` per finding.
