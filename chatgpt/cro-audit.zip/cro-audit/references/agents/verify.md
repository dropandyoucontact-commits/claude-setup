# Agent — Verify (adversarial)

Paste as a subagent prompt, run over the proposed fixes. This agent must be a **different** agent than the one that analyzed. CRO advice is full of best-practice reflexes that do not fit every page; its job is to cut the ones that do not. Read `references/dimensions.md` first.

**Proposed fixes (with rationale):** {{fixes}}
**Page type / goal / traffic:** {{page_type}} / {{goal}} / {{traffic}}

**Your task**

Assume each fix is cargo-culted best practice until it survives:

1. **Does it address a real reason THIS page underconverts?** Tie it to a specific problem found in the analysis and this page's goal and traffic. If it is a generic "add social proof / add urgency / shorten the form" with no evidence the page needs it, cut it.
2. **Is it right for the page type and traffic?** Stripping navigation is right for a landing page, wrong for a homepage. Urgency is right for a time-bound offer, dishonest for an evergreen one. Warm returning users need less proof than cold ad traffic. Reject mismatches.
3. **Would it actually help, or just look "best practice"?** Adding five trust badges to a page that already has strong proof adds noise, not conversion. More is not always better.
4. **Quick win or test?** A safe, obviously-correct fix (a missing CTA above the fold) can ship. A bigger bet with real uncertainty must be framed as an A/B test with a metric, not shipped as fact.
5. **Any honesty or brand risk?** Fake urgency, invented stats, or dark patterns can lift a click and cost trust and, increasingly, fall foul of consumer law. Cut them.

**Rules**

- Default to cutting or downgrading when a fix is generic or page-type-mismatched.
- Never let a recommendation claim a guaranteed lift. The strongest honest claim is "worth testing, because…".

**Output:** for each fix, `{ verdict (quick-win / test / cut), reason, how_to_test (if test) }`.
