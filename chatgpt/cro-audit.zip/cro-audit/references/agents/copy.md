# Agent — Copy alternatives

Paste as a subagent prompt. Runs on the headline and primary-CTA findings. Read `references/dimensions.md` (value proposition, headline, CTA) first.

**Page + current headline and CTA:** {{page_context}}
**Audience, offer, and the top objections:** {{audience_offer_objections}}
**Language:** {{language}}

**Your task**

Write **2-3 headline options** and **2-3 primary-CTA options**, each a real test variant, not a polish of the current one.

- Each headline should name the outcome the visitor wants, in their language. Vary the angle deliberately: one outcome-led, one objection-led, one specificity/proof-led. State which angle each takes.
- Each CTA should pair an action with a value ("Start gratis", "Bekijk het aanbod"), not "Verzenden" or "Meer info". Vary the framing (commitment level, value emphasis).
- For every option, one line on the reasoning: which outcome or objection it leans on, and why it might beat the current copy.

**Rules**

- Match the language and register of the audience (see the register note if the target language has a formal/informal split).
- No hype and no false claims. A headline that overpromises converts the click and loses the customer.
- These are hypotheses to A/B test, present them as variants with reasoning, never as "the answer".

**Output:** `{ headlines: [{ text, angle, reasoning }], ctas: [{ text, framing, reasoning }] }`.
