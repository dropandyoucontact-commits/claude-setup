# Page-type playbook

The same seven dimensions apply everywhere, but what matters most shifts by page type and traffic source. Establish these before auditing: **page type**, **primary conversion goal** (the one action), and **traffic source** (cold ad, warm search, existing user), because they change what a visitor already knows and expects.

## Homepage

Serves many audiences and intents at once, so it clarifies and routes rather than hard-sells.
- Priorities: value proposition, clear paths for the main segments, a primary CTA plus a soft secondary one.
- A homepage legitimately has many links and CTAs; do not treat that as choice overload the way you would on a landing page.

## Landing page (paid or campaign)

One audience, one message, one action. Ruthless focus.
- Priorities: message match to the ad, one dominant CTA, proof, objection handling, and minimal distraction, strip navigation and outbound links.
- The fastest wins here are usually message match and removing competing links.

## Pricing page

High intent, high anxiety. People arrive ready but scared.
- Priorities: plan clarity, the right anchor and recommended plan, objection handling (what happens after trial, can I cancel, hidden costs), proof near the price, and a guarantee or risk-reversal.
- Failures: too many plans, unclear differences, no annual/monthly framing, no answer to "what if it does not work".

## Feature / product page

The visitor is evaluating a specific capability.
- Priorities: tie each feature to an outcome and a use case, show it (screenshot, demo, short video), and put a CTA after the proof.
- Failures: feature specs with no "so what", no visual of the thing working.

## Blog post / content page

Low commercial intent; the goal is usually a soft conversion (subscribe, download, next step), not a hard sell.
- Priorities: a relevant, non-intrusive CTA that matches the reader's stage, an email capture, and internal links to the money pages.
- Do not judge a blog post by hard-conversion standards; its job is to earn the next click.

## Form / checkout

The moment of highest friction and highest intent.
- Priorities: cut fields to the minimum, show progress, reassure at the point of payment (security, guarantee), remove surprise costs, and keep one clear action per step.
- Every removed field and step is a measurable win here.

## Adjacent surfaces (out of scope, note and hand off)

Signup and onboarding flows, in-product activation, and popups/modals are their own disciplines. Flag issues you notice, but this audit is about the page's ability to convert a visitor into the primary action, not the flow that follows.
