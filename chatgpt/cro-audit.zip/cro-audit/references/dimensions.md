# Conversion dimensions

Seven dimensions, roughly in order of how much each tends to move conversion. Work top-down: a broken value proposition is not saved by a better button colour. Items marked *[scan]* are seeded by `scripts/cro-scan.mjs`; the rest are judgement.

## 1. Value proposition clarity

Within about five seconds, can a first-time visitor say what this is, who it is for, and why it beats the alternative (including doing nothing)? This is the single biggest lever.
- Failures: clever-but-vague headlines, feature lists with no outcome, jargon, "we" language instead of "you".
- Check: read only the first screen. If you cannot state the offer and its benefit, neither can the visitor.

## 2. Headline effectiveness *[scan: h1]*

The headline carries most of the value proposition. It should name the outcome the visitor wants, in their words.
- Failures: no `<h1>`, a headline about the company instead of the customer, a pun that hides the point.
- Strong headlines are specific ("Kopen en verkopen zonder commissie") not abstract ("Het slimme platform voor groei").

## 3. Call to action *[scan: CTAs, above-fold, competing count]*

One primary action, obvious, repeated, and low-friction.
- Placement: a primary CTA above the fold and again after each persuasive block.
- Copy: action + value ("Start gratis"), not "Verzenden" or "Meer info".
- Hierarchy: one visually dominant primary CTA. Many equal buttons create choice overload; secondary actions should look secondary.
- Failures: no clear CTA, buried CTA, five competing CTAs, vague label.

## 4. Visual hierarchy & scannability

People skim in an F-pattern before they read. The page must make sense skimmed.
- Check: squint at the page. Does the eye land on the headline, then the CTA? Are sections chunked with subheads, short paragraphs, and whitespace?
- Failures: walls of text, everything the same size, the important thing not the most prominent thing.

## 5. Trust & social proof *[scan: trust keywords, quantified proof]*

Strangers do not buy from strangers. Reduce perceived risk with proof.
- Types: customer logos, ratings and review counts, testimonials with names and specifics, case-study numbers, security and guarantee badges, press or certification.
- Placement matters: proof near the CTA and near the price does the most work.
- Failures: no proof at all, vague proof ("veel tevreden klanten") instead of specifics, proof hidden at the bottom.

## 6. Objection handling

Every visitor has reasons not to act. The page should answer the top ones before they leave.
- Common objections: too expensive, too complex, will not work for me, cannot trust you, bad timing, hidden catch.
- Tools: an FAQ, a comparison, a guarantee or free trial, a "how it works" that removes fear, pricing transparency.
- Check: list the three biggest objections for this offer and audience, then find where the page answers each. Gaps are opportunities.

## 7. Friction *[scan: form fields, links, risk-reversal]*

Every extra step, field, and decision loses people.
- Forms: ask only for what you truly need now; each field costs conversions.
- Steps: shorten the path from intent to done; defer optional info.
- Risk: remove it with a free trial, a guarantee, "no credit card", "cancel anytime".
- Distraction: on a focused landing page, strip navigation and outbound links that let attention leak.
- Failures: long forms, forced account creation, surprise costs late in the flow, a landing page with full site navigation.

## The order matters

Fixing friction (7) on a page with a broken value proposition (1) polishes a leak in a sinking boat. Diagnose top-down, then prioritise fixes by impact, not by how easy they are to ship.
