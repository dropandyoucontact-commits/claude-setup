#!/usr/bin/env node
// CRO Audit — conversion signal scanner. Zero dependencies, Node 18+.
//
// Conversion depends on judgement (is the value proposition clear? does the copy
// answer the objection?), which a script cannot make. But a script CAN extract
// the objective signals that judgement builds on: is there a clear call to
// action, are there competing ones, any trust signals, how heavy is the form,
// how much navigation can leak attention. Treat every line as a signal to weigh,
// not a verdict, and never as a promise that changing it will lift conversion.
//
// Usage:
//   node cro-scan.mjs https://example.com/landing
//   node cro-scan.mjs page.html
//   node cro-scan.mjs https://example.com --json
//
// Exit 0 (informational).

import { readFileSync } from 'node:fs'

const arg = process.argv[2]
const jsonOnly = process.argv.includes('--json')
if (!arg) { console.error('Usage: node cro-scan.mjs <https://url | file.html> [--json]'); process.exit(2) }

let html, finalUrl = arg, status = null
if (/^https?:\/\//i.test(arg)) {
  try {
    const res = await fetch(arg, { redirect: 'follow', headers: { 'user-agent': 'CreativeDeals-cro-audit/1.0' } })
    status = res.status; finalUrl = res.url; html = await res.text()
  } catch (e) { console.error('fetch failed:', e.message); process.exit(2) }
} else html = readFileSync(arg, 'utf8')

const strip = (s) => s.replace(/<[^>]*>/g, ' ').replace(/&[a-z#0-9]+;/gi, ' ').replace(/\s+/g, ' ').trim()
const body = html.replace(/<script[\s\S]*?<\/script>/gi, '').replace(/<style[\s\S]*?<\/style>/gi, '').replace(/<svg[\s\S]*?<\/svg>/gi, '')

// ── headline ─────────────────────────────────────────────────────────────────
const h1s = [...html.matchAll(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi)].map(m => strip(m[1])).filter(Boolean)
const h1 = h1s[0] || null

// ── CTAs ─────────────────────────────────────────────────────────────────────
const ACTION = /\b(koop|kopen|bestel|bestellen|afrekenen|winkelwagen|probeer|start|begin|aanmelden|meld je|registreer|abonneer|download|boek|reserveer|vraag aan|offerte|demo|plan een|neem contact|get started|sign ?up|log ?in|buy|try|subscribe|join|book|request|add to cart|checkout|claim|get)\b/i
const ctas = new Set()
for (const m of body.matchAll(/<(button|a)\b([^>]*)>([\s\S]*?)<\/\1>/gi)) {
  const openAttrs = m[2] || ''
  const text = strip(m[3])
  const looksCta = /\b(btn|button|cta)\b/i.test(openAttrs) || (text && ACTION.test(text) && text.length <= 40)
  if (looksCta && text) ctas.add(text.toLowerCase())
}
const ctaList = [...ctas]
// above-the-fold heuristic: a CTA within the first ~40% of the body text stream
const foldCut = Math.floor(body.length * 0.4)
const ctaAboveFold = ctaList.some(t => {
  const i = body.toLowerCase().indexOf(t)
  return i !== -1 && i < foldCut
})

// ── trust & social proof ─────────────────────────────────────────────────────
const text = strip(body)
const TRUST = ['review', 'beoordeling', 'sterren', 'testimonial', 'klanten', 'trusted', 'vertrouwd', 'garantie', 'guarantee', 'geld terug', 'money back', 'keurmerk', 'certific', 'veilig', 'privacy', 'awarded', 'rated', 'aanbevolen']
const trustHits = TRUST.filter(k => new RegExp(k, 'i').test(text))
const socialProof = [
  ...text.matchAll(/\b\d[\d.,]*\+?\s*(klanten|gebruikers|bedrijven|customers|users|companies|reviews|beoordelingen|downloads|leden|members|bedrijf)/gi),
  ...text.matchAll(/\b[0-5](?:[.,]\d)?\s*\/\s*5\b/g),
  ...text.matchAll(/\b\d{2,}\s*(reviews|beoordelingen)\b/gi),
].map(m => m[0].trim())

// ── friction: form fields ────────────────────────────────────────────────────
let formFields = 0
for (const t of body.match(/<input\b[^>]*>/gi) || []) {
  const type = (t.match(/\btype\s*=\s*["']?([a-z]+)/i) || [])[1] || 'text'
  if (!['hidden', 'submit', 'button', 'image', 'reset'].includes(type.toLowerCase())) formFields++
}
formFields += (body.match(/<select\b/gi) || []).length + (body.match(/<textarea\b/gi) || []).length

// ── attention leakage: links + risk reversal ─────────────────────────────────
const linkCount = (body.match(/<a\b[^>]*\bhref\s*=/gi) || []).length
const riskReversal = /\b(gratis|no credit card|geen creditcard|opzegbaar|annuleer altijd|niet goed geld terug|30 dagen|proefperiode|free trial|cancel anytime)\b/i.test(text)
const urgency = /\b(nog \d+|beperkt|vandaag|laatste|bijna uitverkocht|only \d+ left|ends|verloopt|actie loopt)\b/i.test(text)
const words = (text.match(/\p{L}+/gu) || []).length
const heroImage = /<img\b[^>]*>/i.test(html.slice(0, Math.floor(html.length * 0.35)))

// ── flags ────────────────────────────────────────────────────────────────────
const flags = []
const flag = (sev, msg) => flags.push({ sev, msg })
if (ctaList.length === 0) flag('high', 'No clear call-to-action detected')
else if (!ctaAboveFold) flag('med', 'No CTA appears to be above the fold')
if (ctaList.length > 6) flag('med', `${ctaList.length} distinct CTAs (choice overload risk; fine for a homepage, bad for a landing page)`)
if (!h1) flag('high', 'No <h1> headline (value proposition unclear to skimmers and search)')
if (trustHits.length === 0) flag('med', 'No trust signals found (reviews, guarantees, testimonials, security)')
if (socialProof.length === 0) flag('low', 'No quantified social proof (customer counts, ratings)')
if (formFields > 7) flag('med', `Form has ${formFields} visible fields (friction; ask only for what you need)`)
if (!riskReversal) flag('low', 'No risk-reversal cue (free trial, guarantee, cancel anytime)')
if (linkCount > 30) flag('low', `${linkCount} links (attention can leak; a focused landing page needs few)`)

const result = {
  url: finalUrl, status, headline: h1,
  ctas: ctaList, ctaAboveFold, competingCtas: ctaList.length,
  trustSignals: trustHits, socialProof: [...new Set(socialProof)].slice(0, 8),
  formFields, links: linkCount, riskReversal, urgency, heroImage, wordCount: words, flags,
}

// ── output ───────────────────────────────────────────────────────────────────
if (jsonOnly) { console.log(JSON.stringify(result, null, 2)); process.exit(0) }
console.log(`Conversion signal scan — ${finalUrl}${status ? `  (HTTP ${status})` : ''}\n`)
console.log(`  headline      ${h1 ? `"${h1.slice(0, 70)}"` : '— MISSING'}`)
console.log(`  CTAs          ${ctaList.length ? ctaList.slice(0, 5).map(c => `"${c}"`).join(', ') : '— none detected'}${ctaList.length > 5 ? ' …' : ''}`)
console.log(`  CTA above fold ${ctaAboveFold ? 'yes' : 'no'}`)
console.log(`  trust         ${trustHits.length ? trustHits.join(', ') : '— none'}`)
console.log(`  social proof  ${result.socialProof.length ? result.socialProof.join(' | ') : '— none quantified'}`)
console.log(`  form fields   ${formFields}    links ${linkCount}    risk-reversal ${riskReversal ? 'yes' : 'no'}    urgency ${urgency ? 'yes' : 'no'}`)
console.log(`  hero image    ${heroImage ? 'yes' : 'no'}    words ~${words}`)
console.log('')
if (!flags.length) console.log('No obvious conversion-signal flags. Judge value prop, copy, and objections directly (see dimensions.md).')
else {
  const order = { high: 0, med: 1, low: 2 }
  for (const f of flags.sort((a, b) => order[a.sev] - order[b.sev])) console.log(`  [${f.sev.toUpperCase().padEnd(4)}] ${f.msg}`)
  console.log('\nSignals seed the audit; they are not conversion verdicts. Every fix is a hypothesis to A/B test.')
}
