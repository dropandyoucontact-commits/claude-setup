---
name: cro-audit
description: Audit a live web page for conversion and return specific fixes ordered by expected impact, plus headline and CTA variants to test. Use when asked to improve conversion rate, do a CRO or landing-page audit, review why a page does not convert, or get A/B test ideas. Extracts objective conversion signals with a script, judges the page across seven dimensions, and adversarially cuts generic best-practice advice that does not fit this page.
license: See LICENSE.md
---

# CRO Audit

Reviews a live page and returns a prioritised punch list of conversion fixes, plus headline and CTA variants worth testing. The discipline that makes it useful: it diagnoses top-down (a broken value proposition is not saved by a better button), and a separate agent cuts any "best practice" that does not fit this page's type, traffic, or goal, because most CRO advice is cargo-culted from someone else's page.

It is honest about the one thing CRO cannot fake: you do not know a change works until you test it. Every recommendation is framed as a hypothesis, with quick wins separated from bigger bets that earn an A/B test.

## When to use

Trigger for "improve conversion / CRO audit / why isn't this page converting / landing-page review / give me A/B test ideas". For a quick objective signal dump, run `scripts/cro-scan.mjs` on its own.

## Inputs

- **url** — the live page (required).
- **page type** — homepage, landing, pricing, feature, blog, or form. If not given, infer it and say so.
- **primary goal** — the one action you want (buy, sign up, book, subscribe).
- **traffic source** — cold ad, warm search, or existing user. This changes what the visitor already knows and expects.

## Run order

**1. Signal scan.** `node scripts/cro-scan.mjs <url>` — extracts objective signals: headline, call-to-action detection and position, competing CTAs, trust and social-proof presence, form-field count, link count, risk-reversal and urgency cues. Signals seed the audit; they are not verdicts.

**2. Analyze** (`references/agents/analyze.md`). Judge the page across the seven dimensions in `references/dimensions.md`, top-down: value proposition, headline, CTA, visual hierarchy, trust and social proof, objection handling, friction. Weigh everything against the page type and traffic (`references/page-types.md`). Fan out one analyst per dimension for a deep audit.

**3. Copy** (`references/agents/copy.md`). Write 2-3 headline and 2-3 primary-CTA variants, each with the angle and reasoning. These are test variants, not final answers.

**4. Verify — adversarial** (`references/agents/verify.md`). A *different* agent cuts fixes that are generic best practice with no evidence this page needs them, that mismatch the page type or traffic (urgency on an evergreen offer, stripping nav from a homepage), or that add noise over real gain. It also splits fixes into quick wins (ship now) and bigger bets (test), and kills anything dishonest (fake urgency, invented stats).

**5. Synthesise.** Only survivors reach the report (`references/report-format.md`): a verdict, quick wins, high-impact changes to test (each with how to test it), copy alternatives, unanswered objections, and the raw scan output.

## Principles

- **Diagnose top-down.** Value proposition and headline before button colour. Rank fixes by expected impact, not by how easy they are to ship.
- **Fit over best practice.** A tactic that works on a SaaS pricing page can be wrong on a local service homepage. Match to page type, goal, and traffic.
- **Everything is a hypothesis.** Never claim a change will lift conversion by X%. Separate safe quick wins from bets that need an A/B test.
- **Honesty converts longer.** No fake urgency, invented proof, or dark patterns; they lift a click and cost trust (and can break consumer law).

## Output

One Markdown report (`references/report-format.md`): the biggest reason the page likely underconverts, quick wins, high-impact changes to test (with the variant, metric, and how to read a result), 2-3 headline and CTA alternatives with reasoning, the objections the page ignores, and the raw scan output.

## What this skill will not do

- It will not promise a conversion lift. It gives evidence-based hypotheses and separates safe fixes from ones that need testing.
- It will not recommend dark patterns or invented proof to game a number.
- It audits the page's conversion to its primary action; signup flows, onboarding, and popups are noted but out of scope.
